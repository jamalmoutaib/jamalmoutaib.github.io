# NetOps Script Library

Three production-pattern scripts for multi-vendor network operations. Tested against Cisco IOS/IOS-XE/NX-OS and Arista EOS device types out of the box — extend the command dictionaries at the top of each file for Juniper, Palo Alto, or other Netmiko-supported platforms.

## Setup

```bash
pip install -r requirements.txt
cp inventory.csv.example inventory.csv
# edit inventory.csv with your real device list — never commit this file with real credentials
```

## Scripts

### `netmiko_config_backup.py`
Bulk running-config backup across your inventory, written to a timestamped, per-device directory structure suitable for committing to a config-history git repo.

```bash
python3 netmiko_config_backup.py --inventory inventory.csv --out backups/
```

### `bgp_health_check.py`
Polls BGP neighbor state across your inventory and flags anything not Established. Exit code 2 on findings — wire this into cron + your alerting of choice for a near-real-time flap detector.

```bash
python3 bgp_health_check.py --inventory inventory.csv
```

### `config_diff_report.py`
Diffs the two most recent backups per device (from `netmiko_config_backup.py`'s output structure), or two specific files directly. Surfaces config drift before it surfaces as an incident.

```bash
python3 config_diff_report.py --backup-dir backups/
# or
python3 config_diff_report.py --baseline old.cfg --current new.cfg
```

## Security note

These scripts read credentials from a plaintext CSV for simplicity. For anything beyond a personal lab, pull credentials from environment variables or a secrets manager instead, and never commit a populated `inventory.csv`.

---
Built by [Jamal Moutaib](https://jamalmoutaib.github.io) — more real-incident networking content at the blog.
