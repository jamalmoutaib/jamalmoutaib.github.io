#!/usr/bin/env python3
"""
bgp_health_check.py

Polls BGP neighbor state across a multi-vendor device inventory via Netmiko
and flags any session not in the Established state. Designed to be run on a
schedule (cron) and alert on non-zero exit code, or run ad hoc during a
suspected flapping incident.

Usage:
    python3 bgp_health_check.py --inventory inventory.csv

inventory.csv columns (header row required):
    hostname,ip,device_type,username,password

Supported device_type values (extend SHOW_BGP_COMMANDS / parser as needed):
    cisco_ios, cisco_xe, cisco_nxos, arista_eos

This intentionally uses simple line-based parsing rather than a full
TextFSM/genie template set, so it's portable to a fresh laptop with nothing
but `pip install netmiko`. Swap in TextFSM templates if you need
production-grade parsing across many platform variants.
"""
import argparse
import csv
import logging
import re
import sys
from pathlib import Path

from netmiko import ConnectHandler
from netmiko.exceptions import NetmikoTimeoutException, NetmikoAuthenticationException

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

SHOW_BGP_COMMANDS = {
    "cisco_ios": "show ip bgp summary",
    "cisco_xe": "show ip bgp summary",
    "cisco_nxos": "show ip bgp summary",
    "arista_eos": "show ip bgp summary",
}

# Matches lines like: 203.0.113.1   4   65001   18234   18211   42   0   0   3d12h   Established
# or, when not established, the state/PfxRcd column shows "Active", "Idle", "Connect", or a count.
NEIGHBOR_LINE_RE = re.compile(
    r"^\s*(?P<neighbor>\d+\.\d+\.\d+\.\d+)\s+\d+\s+(?P<asn>\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\S+\s+(?P<state>\S+)\s*$"
)


def check_device(device: dict) -> list[dict]:
    hostname = device["hostname"]
    device_type = device["device_type"]
    command = SHOW_BGP_COMMANDS.get(device_type)
    if not command:
        log.warning("%s: unsupported device_type '%s', skipping", hostname, device_type)
        return []

    conn_params = {
        "device_type": device_type,
        "host": device["ip"],
        "username": device["username"],
        "password": device["password"],
        "timeout": 30,
    }

    findings = []
    try:
        with ConnectHandler(**conn_params) as conn:
            output = conn.send_command(command, read_timeout=60)
    except NetmikoAuthenticationException:
        log.error("%s: authentication failed", hostname)
        return [{"hostname": hostname, "neighbor": None, "state": "UNREACHABLE-AUTH"}]
    except NetmikoTimeoutException:
        log.error("%s: connection timed out", hostname)
        return [{"hostname": hostname, "neighbor": None, "state": "UNREACHABLE-TIMEOUT"}]

    for line in output.splitlines():
        match = NEIGHBOR_LINE_RE.match(line)
        if not match:
            continue
        state = match.group("state")
        # A pure integer in this column means N prefixes received — that IS established.
        is_established = state.isdigit() or state.lower() == "established"
        if not is_established:
            findings.append(
                {
                    "hostname": hostname,
                    "neighbor": match.group("neighbor"),
                    "asn": match.group("asn"),
                    "state": state,
                }
            )
    return findings


def load_inventory(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", required=True, type=Path, help="Path to inventory CSV")
    args = parser.parse_args()

    devices = load_inventory(args.inventory)
    if not devices:
        log.error("No devices found in %s", args.inventory)
        sys.exit(1)

    all_findings = []
    for device in devices:
        all_findings.extend(check_device(device))

    if not all_findings:
        log.info("All BGP sessions established across %d device(s).", len(devices))
        sys.exit(0)

    log.warning("%d non-established BGP session(s) found:", len(all_findings))
    for f in all_findings:
        log.warning("  %s — neighbor %s — state: %s", f["hostname"], f.get("neighbor"), f["state"])
    sys.exit(2)


if __name__ == "__main__":
    main()
