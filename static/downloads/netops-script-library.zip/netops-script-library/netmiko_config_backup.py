#!/usr/bin/env python3
"""
netmiko_config_backup.py

Bulk configuration backup across multi-vendor network devices using Netmiko.
Reads device inventory from a CSV, connects to each device, pulls the running
config, and writes it to a timestamped, git-friendly directory structure.

Usage:
    python3 netmiko_config_backup.py --inventory inventory.csv --out backups/

inventory.csv columns (header row required):
    hostname,ip,device_type,username,password

device_type must be a valid Netmiko device_type string, e.g.:
    cisco_ios, cisco_nxos, cisco_xe, arista_eos, juniper_junos, paloalto_panos

Notes:
- Credentials are read from the CSV for simplicity. In production, pull them
  from environment variables or a secrets manager — never commit a populated
  inventory.csv to git.
- Exit code is non-zero if any device fails, so this is safe to wire into a
  cron job or CI pipeline with alerting on failure.
"""
import argparse
import csv
import logging
import sys
from datetime import datetime
from pathlib import Path

from netmiko import ConnectHandler
from netmiko.exceptions import NetmikoTimeoutException, NetmikoAuthenticationException

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# Commands to pull the running config per platform family.
SHOW_RUN_COMMANDS = {
    "cisco_ios": "show running-config",
    "cisco_xe": "show running-config",
    "cisco_nxos": "show running-config",
    "arista_eos": "show running-config",
    "juniper_junos": "show configuration",
    "paloalto_panos": "show config running",
}


def backup_device(device: dict, out_dir: Path) -> bool:
    hostname = device["hostname"]
    device_type = device["device_type"]
    command = SHOW_RUN_COMMANDS.get(device_type, "show running-config")

    conn_params = {
        "device_type": device_type,
        "host": device["ip"],
        "username": device["username"],
        "password": device["password"],
        "timeout": 30,
    }

    try:
        with ConnectHandler(**conn_params) as conn:
            output = conn.send_command(command, read_timeout=60)
    except NetmikoAuthenticationException:
        log.error("%s: authentication failed", hostname)
        return False
    except NetmikoTimeoutException:
        log.error("%s: connection timed out", hostname)
        return False
    except Exception as exc:  # noqa: BLE001 — log and continue with the batch
        log.error("%s: unexpected error — %s", hostname, exc)
        return False

    device_dir = out_dir / hostname
    device_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_path = device_dir / f"{hostname}_{ts}.cfg"
    backup_path.write_text(output, encoding="utf-8")

    log.info("%s: backup saved to %s (%d bytes)", hostname, backup_path, len(output))
    return True


def load_inventory(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", required=True, type=Path, help="Path to inventory CSV")
    parser.add_argument("--out", required=True, type=Path, help="Output directory for backups")
    args = parser.parse_args()

    devices = load_inventory(args.inventory)
    if not devices:
        log.error("No devices found in %s", args.inventory)
        sys.exit(1)

    args.out.mkdir(parents=True, exist_ok=True)

    failures = 0
    for device in devices:
        if not backup_device(device, args.out):
            failures += 1

    log.info("Done: %d/%d devices backed up successfully", len(devices) - failures, len(devices))
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
