#!/usr/bin/env python3
"""
config_diff_report.py

Compares two configuration snapshots — e.g. yesterday's backup vs. today's,
or running vs. a known-good baseline — and produces a human-readable drift
report. Designed to run against the output directory structure produced by
netmiko_config_backup.py (one subfolder per hostname, timestamped .cfg files).

Usage:
    # Compare the two most recent backups for every device in backups/
    python3 config_diff_report.py --backup-dir backups/

    # Compare two specific files directly
    python3 config_diff_report.py --baseline old.cfg --current new.cfg
"""
import argparse
import difflib
import sys
from pathlib import Path


def diff_text(baseline: str, current: str, label: str) -> str:
    diff = list(
        difflib.unified_diff(
            baseline.splitlines(keepends=True),
            current.splitlines(keepends=True),
            fromfile=f"{label} (baseline)",
            tofile=f"{label} (current)",
        )
    )
    return "".join(diff)


def latest_two_backups(device_dir: Path) -> tuple[Path, Path] | None:
    files = sorted(device_dir.glob("*.cfg"))
    if len(files) < 2:
        return None
    return files[-2], files[-1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backup-dir", type=Path, help="Root backup directory (one subfolder per device)")
    parser.add_argument("--baseline", type=Path, help="Specific baseline config file")
    parser.add_argument("--current", type=Path, help="Specific current config file")
    args = parser.parse_args()

    any_drift = False

    if args.baseline and args.current:
        baseline_text = args.baseline.read_text(encoding="utf-8")
        current_text = args.current.read_text(encoding="utf-8")
        diff = diff_text(baseline_text, current_text, args.current.stem)
        if diff:
            any_drift = True
            print(diff)
        else:
            print(f"No drift: {args.current.name} matches {args.baseline.name}")

    elif args.backup_dir:
        if not args.backup_dir.is_dir():
            print(f"Backup dir not found: {args.backup_dir}", file=sys.stderr)
            sys.exit(1)

        for device_dir in sorted(p for p in args.backup_dir.iterdir() if p.is_dir()):
            pair = latest_two_backups(device_dir)
            if not pair:
                print(f"{device_dir.name}: fewer than 2 backups, skipping")
                continue
            baseline_path, current_path = pair
            diff = diff_text(
                baseline_path.read_text(encoding="utf-8"),
                current_path.read_text(encoding="utf-8"),
                device_dir.name,
            )
            if diff:
                any_drift = True
                print(f"\n===== DRIFT DETECTED: {device_dir.name} =====")
                print(diff)
            else:
                print(f"{device_dir.name}: no drift")
    else:
        parser.error("Provide either --backup-dir, or both --baseline and --current")

    sys.exit(1 if any_drift else 0)


if __name__ == "__main__":
    main()
